<?php

namespace App\Interfaces\Http\Controllers;

abstract class Controller
{
    //
}
