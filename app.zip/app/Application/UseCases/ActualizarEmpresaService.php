<?php

namespace App\Application\UseCases;

use App\Application\DTOs\EmpresaDTO;
use App\Domain\Entities\Empresa;
use App\Domain\Repositories\EmpresaRepositoryInterface;
use App\Exceptions\EmpresaNoEncontradaException;

class ActualizarEmpresaService
{
    public function __construct(
        private EmpresaRepositoryInterface $repository
    ) {}

    public function handle(string $nit, EmpresaDTO $empresaDTO): Empresa
    {
        $empresaExistente = $this->repository->obtenerPorNit($nit);

        $empresaExistente->nombre    = $empresaDTO->getNombre();
        $empresaExistente->direccion = $empresaDTO->getDireccion();
        $empresaExistente->telefono  = $empresaDTO->getTelefono();
        $empresaExistente->estado  = $empresaDTO->getEstado();

        return $this->repository->actualizar($empresaExistente);
    }
}
