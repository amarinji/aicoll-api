<?php

namespace App\Application\DTOs;

use InvalidArgumentException;

/**
 * DTO que representa una Empresa
 *
 * @property string      $nit
 * @property string      $nombre
 * @property string|null $direccion
 * @property string|null $telefono
 * @property string|null $estado
 */
final class EmpresaDTO
{
    public readonly string      $nit;
    public readonly string      $nombre;
    public readonly ?string     $direccion;
    public readonly ?string     $telefono;
    public readonly ?string     $estado;

    public function __construct(
        ?string $nit,
        string  $nombre,
        ?string $direccion = null,
        ?string $telefono  = null,
        ?string $estado    = null
    ) {
        // 1) Primero: si $nit es null o cadena vacía, directamente error.
        if ($nit === null || trim($nit) === '') {
            throw new InvalidArgumentException("El NIT debe ser un número válido.");
        }

        // 2) Ahora chequeamos que $nit sólo contenga dígitos:
        if (! preg_match('/^\d+$/', $nit)) {
            throw new InvalidArgumentException("El NIT debe ser un número válido.");
        }

        // 3) Validamos nombre obligatorio:
        if (trim($nombre) === '') {
            throw new InvalidArgumentException("El nombre es obligatorio.");
        }

        $this->nit       = $nit;
        $this->nombre    = $nombre;
        $this->direccion = $direccion;
        $this->telefono  = $telefono;
        $this->estado    = $estado;
    }

    /**
     * Utilidad para construir un DTO sin enviar NIT (por ejemplo, en actualizaciones)
     * Si utilizas este método, el servicio debe recibir el NIT por separado.
     */
    public static function createWithoutNit(
        string      $nombre,
        ?string     $direccion = null,
        ?string     $telefono  = null,
        ?string     $estado    = null
    ): self {
        // Pasamos "0" temporal para que no falle la validación interna de __construct.
        return new self("0", $nombre, $direccion, $telefono, $estado);
    }

    public function getNit(): string
    {
        return $this->nit;
    }

    public function getNombre(): string
    {
        return $this->nombre;
    }

    public function getDireccion(): ?string
    {
        return $this->direccion;
    }

    public function getTelefono(): ?string
    {
        return $this->telefono;
    }

    public function getEstado(): ?string
    {
        return $this->estado;
    }

    public function telefonoFormateado(): ?string
    {
        return $this->telefono !== null
            ? preg_replace('/\D+/', '', $this->telefono)
            : null;
    }
}
